package com.demo.spring;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLogger {

	@Before("execution(* com.demo.spring.EmpApp.rregisterEmp(..))")
	public void logBefore() {
		System.out.println("Before method call...");
	}

	@AfterReturning(pointcut="execution(* com.demo.spring.EmpApp.rregisterEmp(..))")
	public void logAfter() {
		System.out.println("After method returns...");
	}
}
